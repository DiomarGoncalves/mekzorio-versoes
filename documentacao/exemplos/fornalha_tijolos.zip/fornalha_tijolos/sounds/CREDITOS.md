# Créditos dos sons — Fornalha de tijolos

`brick_furnace_loop.wav` (mono, 16 bits PCM, 44,1 kHz, 10 s, loop sem emenda) é gerado por
`arte/sons/mod_fornalha_som.py` (só biblioteca padrão do Python; semente fixa, sempre o mesmo
arquivo). O script usa as funções de `arte/sons/sndlib.py` e `arte/sons/gerar_sons.py`.

Como foi feito: síntese própria + trechos de gravações **CC0 (domínio público)** que já estão em
`arte/sons/originais/` (os mesmos usados pelo mod base; nada novo foi baixado). CC0 permite uso
comercial, modificação e redistribuição sem exigir atribuição; os autores estão listados por
cortesia.

- **Fogo de verdade:** a gravação de lareira `originais/fireplace.wav` (a mesma base do
  `furnace_loop` do mod base), tocada a 84 % da velocidade (cerca de 3 semitons mais grave,
  estalos mais lentos) e a partir de outro ponto, para soar como um fogo maior e não como cópia.
- **Tiragem da chaminé (síntese):** ruído filtrado abaixo de ~110 Hz e uma faixa em ~60 Hz,
  respirando em ciclos lentos e diferentes entre si; uma ressonância estreita de ruído em
  ~45 Hz faz o zumbido quente e grave (é ruído, não um tom de motor elétrico).
- **Carvão (síntese):** estalidos suaves e esparsos e 5 estouros discretos de brasa em tempos
  irregulares.
- **Carvão assentando:** uma vez por loop, `originais/rock_fall_5.wav` a meia velocidade,
  escurecido e bem baixo.

Tudo passa pelo mesmo acabamento dos loops do mod base (passa-baixa de 24 dB/oitava em
~3 kHz, filtros circulares para o loop fechar sem clique) e fica com a mesma intensidade
(K-ponderada) do `furnace_loop` (−25), com teto de pico de −3 dBFS.

| Trecho | Pacote (OpenGameArt) | Autor | Licença |
|---|---|---|---|
| `fireplace.wav` (`fire.wav`, 12 s a partir de 2 s) | [Fireplace Sound loop](https://opengameart.org/content/fireplace-sound-loop) | PagDev | CC0 |
| `rock_fall_5.wav` (`bfh1_rock_falling_05.ogg`) | [75 CC0 breaking / falling / hit sfx](https://opengameart.org/content/75-cc0-breaking-falling-hit-sfx) | rubberduck | CC0 |

A origem exata de cada trecho (arquivo do pacote e corte) está em
`arte/sons/preparar_originais.py`; a licença de cada pacote foi conferida quando o mod base foi
feito (ver `mods/base/sounds/CREDITOS.md`).
