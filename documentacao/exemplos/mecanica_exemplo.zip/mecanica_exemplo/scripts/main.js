// Mod de exemplo "mecanica_exemplo": motor rotativo + caixa de engrenagem.
// Referência de todas as funções: docs/mods-api.md. Para o VS Code completar, copie mods/mekzorio.d.ts para esta pasta.
//
// Como funciona:
//  - O MOTOR queima 1 carvão a cada 10 segundos e gira até 120 rpm (sem carvão, vai parando).
//  - A CAIXA DE ENGRENAGEM encostada no motor recebe a rotação. A relação escolhida na janela dela troca velocidade
//    por força: 1:1 é rápida mas fraca demais para prensar; 1:2 prensa 1 engrenagem a cada 4 voltas do eixo de saída;
//    1:4 tem força de sobra mas gira devagar. Cada engrenagem gasta 2 placas de ferro.
//  - O LADRÃO DE ENGRENAGENS (comando /ladrao) mostra a API de inimigos: ele vai até a caixa, rouba e foge.
import { buildings, enemies, commands, players, world, ui, console } from "mekzorio";

const MOTOR = "mecanica_exemplo:motor_rotativo";
const CAIXA = "mecanica_exemplo:caixa_engrenagem";
const RPM_MAX = 120;
const VOLTAS_POR_ENGRENAGEM = 4;
const FORCA_MINIMA = 2;

// ---------- Motor ----------
buildings.onTick(MOTOR, 30, m => {          // 30 ticks = a cada 1 segundo
  let rpm = m.data.get("rpm") ?? 0;          // m.data: dados deste mod nesta máquina, salvos com o mundo
  let fogo = m.data.get("fogo") ?? 0;        // segundos de carvão que ainda restam
  if (fogo <= 0 && m.extract("coal", 1) === 1) fogo = 10;
  if (fogo > 0) { fogo -= 1; rpm = Math.min(RPM_MAX, rpm + 30); }
  else rpm = Math.max(0, rpm - 20);
  m.data.set("fogo", fogo);
  m.data.set("rpm", rpm);
  // O volante gira na velocidade do motor (graus por segundo = rpm × 6). Gira no computador de cada jogador.
  m.pose("volante", rpm > 0 ? { spin: [rpm * 6, 0, 0] } : null);
});

// ---------- Caixa de engrenagem ----------
function rotacaoDeEntrada(c) {
  let rpm = 0;
  for (const n of c.neighbors())             // máquinas encostadas, com o lado
    if (n.building.type === MOTOR) rpm = Math.max(rpm, n.building.data.get("rpm") ?? 0);
  return rpm;
}

function estado(c) {
  const relacao = c.data.get("relacao") ?? 2;
  const rpm = rotacaoDeEntrada(c);
  const forca = relacao;                     // reduzir a velocidade aumenta a força
  return { relacao, rpm, saida: rpm / relacao, forca, progresso: c.data.get("progresso") ?? 0, feitas: c.data.get("feitas") ?? 0 };
}

const abertas = new Map();                   // caixa → jogadores com a janela aberta (só na memória do script)

buildings.onTick(CAIXA, 30, c => {
  const e = estado(c);
  // As duas engrenagens do modelo giram em sentidos opostos.
  c.pose("engrenagem_a", e.rpm > 0 ? { spin: [0, e.rpm * 6, 0] } : null);
  c.pose("engrenagem_b", e.saida > 0 ? { spin: [0, -e.saida * 6, 0] } : null);
  if (e.rpm > 0 && e.forca >= FORCA_MINIMA && c.count("iron_plate") >= 2) {
    let progresso = e.progresso + e.saida / 60;          // voltas do eixo de saída neste segundo
    if (progresso >= VOLTAS_POR_ENGRENAGEM && c.insert("iron_gear", 1) === 1) {
      c.extract("iron_plate", 2);
      progresso -= VOLTAS_POR_ENGRENAGEM;
      c.data.set("feitas", e.feitas + 1);
    }
    c.data.set("progresso", Math.min(progresso, VOLTAS_POR_ENGRENAGEM));
  }
  for (const player of abertas.get(c.id) ?? []) mostrar(c, player);   // janela aberta: atualiza
});

// ---------- Janela da caixa ----------
function mostrar(c, player) {
  const e = estado(c);
  const aviso = e.rpm === 0 ? "Sem rotação: encoste um motor rotativo com carvão."
    : e.forca < FORCA_MINIMA ? "Força baixa demais para prensar: escolha 1:2 ou 1:4."
    : c.count("iron_plate") < 2 ? "Coloque placas de ferro (2 por engrenagem)."
    : "Prensando engrenagens.";
  const botao = r => ({ type: "button", id: "r" + r, text: `1:${r}`, primary: e.relacao === r });
  ui.show(player, {
    id: "caixa" + c.id, title: "Caixa de engrenagem", width: 400, building: c.id,
    body: [
      { type: "text", text: `Entrada: ${e.rpm} rpm   ·   saída: ${Math.round(e.saida)} rpm   ·   força: ${e.forca}×` },
      { type: "text", text: "Relação (velocidade × força):", color: "dim", size: 13 },
      { type: "row", children: [botao(1), botao(2), botao(4)] },
      { type: "bar", value: e.progresso / VOLTAS_POR_ENGRENAGEM, text: "próxima engrenagem" },
      // Os 4 espaços da caixa ("container" no JSON), ao vivo e arrastáveis como nos baús do jogo. Com espaços na
      // janela, a janela padrão da máquina não abre junto: esta faz o papel dela.
      { type: "text", text: "Placas de ferro entram, engrenagens saem:", color: "dim", size: 13 },
      { type: "slots", from: 0, count: 4, columns: 4 },
      { type: "text", text: `Engrenagens feitas: ${e.feitas}` },
      { type: "text", text: aviso, color: e.rpm > 0 && e.forca >= FORCA_MINIMA ? "energy" : "accent" },
    ],
  }, ev => {
    if (ev.closed) { abertas.get(c.id)?.delete(ev.player.id); return; }
    if (ev.button.startsWith("r")) { c.data.set("relacao", Number(ev.button.slice(1))); mostrar(c, ev.player.id); }
  });
}

buildings.onInteract(CAIXA, (c, player) => {
  if (!abertas.has(c.id)) abertas.set(c.id, new Set());
  abertas.get(c.id).add(player.id);
  mostrar(c, player.id);
});

// ---------- Ladrão de engrenagens (API de inimigos) ----------
// /ladrao (administrador): chama um ladrão perto da caixa de engrenagem mais próxima de você. Ele anda até a caixa,
// leva até 10 engrenagens e foge. Derrube-o e o roubo cai no chão; se ele chegar longe, some com tudo.
const LADRAO = "mecanica_exemplo:ladrao_engrenagens";

commands.register("ladrao", player => {
  const caixa = buildings.find({ type: CAIXA, x: player.x, y: player.y, radius: 64 })[0];
  if (!caixa) return "Ponha uma caixa de engrenagem perto de você primeiro.";
  const e = enemies.spawn(LADRAO, caixa.x + 14.5, caixa.y + 1.5);
  if (!e) return "Não deu para chamar o ladrão (o mundo Pacífico não tem inimigos).";
  e.data.set("caixa", caixa.id);             // e.data: dados deste mod neste inimigo, salvos com o mundo
  e.data.set("quem", player.id);
  e.data.set("fase", "indo");
  return "Um ladrão de engrenagens está indo para a sua caixa!";
}, { admin: true, description: "chama um ladrão de engrenagens (exemplo da API de inimigos)" });

// A cada meio segundo, para cada ladrão vivo. As ordens (moveTo) não vão no save: mandando de novo aqui, ele segue o
// plano mesmo depois de o mundo ser fechado e aberto.
enemies.onTick(LADRAO, 15, e => {
  const fase = e.data.get("fase");
  if (fase === "indo") {
    const caixa = buildings.get(e.data.get("caixa") ?? 0);
    if (!caixa) { e.data.set("fase", "fugindo"); return; }
    const alvoX = caixa.x + 1, alvoY = caixa.y + 2.6;   // na frente da caixa (2x2)
    if (Math.hypot(e.x - alvoX, e.y - alvoY) > 0.8) { e.moveTo(alvoX, alvoY); return; }
    const levou = caixa.extract("iron_gear", 10);
    e.data.set("levou", levou);
    e.data.set("fase", "fugindo");
    players.message(e.data.get("quem"), levou > 0 ? `O ladrão levou ${levou} engrenagens! Pegue ele!` : "O ladrão não achou engrenagens e vai embora.");
  } else if (fase === "fugindo") {
    const fugaX = e.data.get("fugaX") ?? e.x + 30;
    e.data.set("fugaX", fugaX);
    const passos = (e.data.get("passos") ?? 0) + 1;   // 60 × meio segundo = 30 s: preso (água no caminho) também some
    e.data.set("passos", passos);
    if (Math.abs(e.x - fugaX) > 1 && passos < 60) { e.moveTo(fugaX, e.y); return; }
    const levou = e.data.get("levou") ?? 0;
    if (levou > 0) players.message(e.data.get("quem"), `O ladrão fugiu com ${levou} engrenagens.`);
    e.remove();                              // some sem soltar nada
  }
});

// Derrubado: o que ele levou cai no chão (d.data traz os dados que este mod guardou nele).
enemies.onDefeated(d => {
  if (d.type !== LADRAO || !(d.data?.levou > 0)) return;
  world.dropItems(Math.floor(d.x), Math.floor(d.y), "iron_gear", d.data.levou);
  players.message(d.data.quem, `Você pegou de volta ${d.data.levou} engrenagens.`);
});

console.log("mecânica de exemplo carregada");
