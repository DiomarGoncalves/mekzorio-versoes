// Mod de exemplo "mecanica_exemplo": motor rotativo + caixa de engrenagem.
// Referência de todas as funções: docs/mods-api.md. Para o VS Code completar, copie mods/mekzorio.d.ts para esta pasta.
//
// Como funciona:
//  - O MOTOR queima 1 carvão a cada 10 segundos e gira até 120 rpm (sem carvão, vai parando).
//  - A CAIXA DE ENGRENAGEM encostada no motor recebe a rotação. A relação escolhida na janela dela troca velocidade
//    por força: 1:1 é rápida mas fraca demais para prensar; 1:2 prensa 1 engrenagem a cada 4 voltas do eixo de saída;
//    1:4 tem força de sobra mas gira devagar. Cada engrenagem gasta 2 placas de ferro.
import { buildings, ui, console } from "mekzorio";

const MOTOR = "mecanica_exemplo:motor_rotativo";
const CAIXA = "mecanica_exemplo:caixa_engrenagem";
const RPM_MAX = 120;
const VOLTAS_POR_ENGRENAGEM = 4;
const FORCA_MINIMA = 2;

// ---------- Motor ----------
buildings.onTick(MOTOR, 30, m => {          // 30 ticks = a cada 1 segundo
  let rpm = m.data.get("rpm") ?? 0;          // m.data: dados deste mod nesta máquina, salvos com o mundo
  let fogo = m.data.get("fogo") ?? 0;        // segundos de carvão que ainda restam
  if (fogo <= 0 && m.extract("coal", 1) === 1) fogo = 10;
  if (fogo > 0) { fogo -= 1; rpm = Math.min(RPM_MAX, rpm + 30); }
  else rpm = Math.max(0, rpm - 20);
  m.data.set("fogo", fogo);
  m.data.set("rpm", rpm);
  // O volante gira na velocidade do motor (graus por segundo = rpm × 6). Gira no computador de cada jogador.
  m.pose("volante", rpm > 0 ? { spin: [rpm * 6, 0, 0] } : null);
});

// ---------- Caixa de engrenagem ----------
function rotacaoDeEntrada(c) {
  let rpm = 0;
  for (const n of c.neighbors())             // máquinas encostadas, com o lado
    if (n.building.type === MOTOR) rpm = Math.max(rpm, n.building.data.get("rpm") ?? 0);
  return rpm;
}

function estado(c) {
  const relacao = c.data.get("relacao") ?? 2;
  const rpm = rotacaoDeEntrada(c);
  const forca = relacao;                     // reduzir a velocidade aumenta a força
  return { relacao, rpm, saida: rpm / relacao, forca, progresso: c.data.get("progresso") ?? 0, feitas: c.data.get("feitas") ?? 0 };
}

const abertas = new Map();                   // caixa → jogadores com a janela aberta (só na memória do script)

buildings.onTick(CAIXA, 30, c => {
  const e = estado(c);
  // As duas engrenagens do modelo giram em sentidos opostos.
  c.pose("engrenagem_a", e.rpm > 0 ? { spin: [0, e.rpm * 6, 0] } : null);
  c.pose("engrenagem_b", e.saida > 0 ? { spin: [0, -e.saida * 6, 0] } : null);
  if (e.rpm > 0 && e.forca >= FORCA_MINIMA && c.count("iron_plate") >= 2) {
    let progresso = e.progresso + e.saida / 60;          // voltas do eixo de saída neste segundo
    if (progresso >= VOLTAS_POR_ENGRENAGEM && c.insert("iron_gear", 1) === 1) {
      c.extract("iron_plate", 2);
      progresso -= VOLTAS_POR_ENGRENAGEM;
      c.data.set("feitas", e.feitas + 1);
    }
    c.data.set("progresso", Math.min(progresso, VOLTAS_POR_ENGRENAGEM));
  }
  for (const player of abertas.get(c.id) ?? []) mostrar(c, player);   // janela aberta: atualiza
});

// ---------- Janela da caixa ----------
function mostrar(c, player) {
  const e = estado(c);
  const aviso = e.rpm === 0 ? "Sem rotação: encoste um motor rotativo com carvão."
    : e.forca < FORCA_MINIMA ? "Força baixa demais para prensar: escolha 1:2 ou 1:4."
    : c.count("iron_plate") < 2 ? "Coloque placas de ferro (2 por engrenagem)."
    : "Prensando engrenagens.";
  const botao = r => ({ type: "button", id: "r" + r, text: `1:${r}`, primary: e.relacao === r });
  ui.show(player, {
    id: "caixa" + c.id, title: "Caixa de engrenagem", width: 400, building: c.id,
    body: [
      { type: "text", text: `Entrada: ${e.rpm} rpm   ·   saída: ${Math.round(e.saida)} rpm   ·   força: ${e.forca}×` },
      { type: "text", text: "Relação (velocidade × força):", color: "dim", size: 13 },
      { type: "row", children: [botao(1), botao(2), botao(4)] },
      { type: "bar", value: e.progresso / VOLTAS_POR_ENGRENAGEM, text: "próxima engrenagem" },
      { type: "row", children: [ { type: "icon", item: "iron_gear", count: e.feitas, text: `Engrenagens feitas: ${e.feitas}` } ] },
      { type: "text", text: aviso, color: e.rpm > 0 && e.forca >= FORCA_MINIMA ? "energy" : "accent" },
    ],
  }, ev => {
    if (ev.closed) { abertas.get(c.id)?.delete(ev.player.id); return; }
    if (ev.button.startsWith("r")) { c.data.set("relacao", Number(ev.button.slice(1))); mostrar(c, ev.player.id); }
  });
}

buildings.onInteract(CAIXA, (c, player) => {
  if (!abertas.has(c.id)) abertas.set(c.id, new Set());
  abertas.get(c.id).add(player.id);
  mostrar(c, player.id);
});

console.log("mecânica de exemplo carregada");
